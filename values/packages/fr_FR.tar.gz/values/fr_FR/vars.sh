#!/bin/bash

#########################################
# This file defines some of the variables
# used by the game. Variables should
# never be null
#########################################

# Number of lives with which the players
# starts the game
LIVES=3

# Limited time to give an answer. If set
# to zero, disables the timer.
TIMER=0

#########################################
# Do not modify the following unless you
# are confident in what you are doing.
# Modifications could result in partial
# or total malfunctioning of the game.
#########################################

SCORE=0
COUNT=1
RATIO=0
ROW=0
BEST=0

HINT=
EXPC=
INPUT=none

USER=${USER:-$(whoami >/dev/null)}

WITNESS=1
